package com.cobiscorp.postulacion.libros.repositories;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.cobiscorp.postulacion.libros.models.BookModel;


@Component
public class DataBaseInit implements CommandLineRunner {

    private final BookRepository bookRepository;

    @Autowired
    public DataBaseInit(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        // Aquí puedes agregar los datos que deseas insertar en la tabla
        BookModel book1 = new BookModel();
        book1.setTitulo("Título 1");
        book1.setReferencia("Referencia 1");
        book1.setAutor("Autor 1");
        book1.setUbicacion("Ubicación 1");
        book1.setPrecio(10.99);
        
        BookModel book2 = new BookModel();
        book2.setTitulo("Título 2");
        book2.setReferencia("Referencia 2");
        book2.setAutor("Autor 2");
        book2.setUbicacion("Ubicación 2");
        book2.setPrecio(15.99);
        
        // Guardar los libros en la base de datos
        bookRepository.save(book1);
        bookRepository.save(book2);
    }
}