package com.cobiscorp.postulacion.libros.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Libro_Anteliz")
public class BookModel{

    @Id
    @Column(unique = true, nullable = false,length = 150)
    private String titulo;
    @Column(nullable = false,length = 300)
    private String referencia;
    @Column(nullable = false,length = 150)
    private String autor;
    private String ubicacion;
    private double precio;

    public BookModel(){

    }
    public BookModel(String titulo, String referencia, String autor, String ubicacion, double precio) {
        this.titulo = titulo;
        this.referencia = referencia;
        this.autor = autor;
        this.ubicacion = ubicacion;
        this.precio = precio;
    }

    public String gettitulo() {
        return titulo;
    }

    public void settitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getreferencia() {
        return referencia;
    }

    public void setreferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getautor() {
        return autor;
    }

    public void setautor(String autor) {
        this.autor = autor;
    }

    public String getubicacion() {
        return ubicacion;
    }

    public void setubicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public double getprecio() {
        return precio;
    }

    public void setprecio(double precio) {
        this.precio = precio;
    }
}