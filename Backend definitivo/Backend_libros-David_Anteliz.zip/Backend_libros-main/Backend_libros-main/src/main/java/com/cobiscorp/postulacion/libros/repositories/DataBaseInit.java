package com.cobiscorp.postulacion.libros.repositories;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.cobiscorp.postulacion.libros.models.BookModel;


@Component
public class DataBaseInit implements CommandLineRunner {

    private final BookRepository bookRepository;

    @Autowired
    public DataBaseInit(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        // Aquí puedes agregar los datos que deseas insertar en la tabla
        BookModel book1 = new BookModel();
        book1.settitulo("StarWars");
        book1.setreferencia("1A");
        book1.setautor("Shakira");
        book1.setubicacion("Bogotá");
        book1.setprecio(10.99);
        
        BookModel book2 = new BookModel();
        book2.settitulo("Blink-182");
        book2.setreferencia("1AA");
        book2.setautor("Travis Barker");
        book2.setubicacion("Estados Unidos");
        book2.setprecio(15.99);
        
        // Guardar los libros en la base de datos
        bookRepository.save(book1);
        bookRepository.save(book2);
    }
}